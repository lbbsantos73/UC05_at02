using System;
using System.Collections.Generic;

namespace at02.Models
{
    public class Pedido
    {
        private static List<ItemPedido> lista = new List<ItemPedido>();

        public void IncluirItem(ItemPedido u)
        {
            lista.Add(u);
        }

        public double TotalizarPedido()
        {
            double resultado = 0;
            for(int i=0; i<lista.Count; i++)
            {
                resultado = resultado + lista[i].valor_unitario*lista[i].quantidade;
            }
            return resultado;
        }

        public List<ItemPedido> Listar()
        {
            return(lista);
        }


    }
}