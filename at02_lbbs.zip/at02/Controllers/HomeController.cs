﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using at02.Models;

namespace at02.Controllers
{
    public class HomeController : Controller
    {

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Cadastro(ItemPedido u)
        {
            Dados.PedidoAtual.IncluirItem(u);
            List<ItemPedido> lista = Dados.PedidoAtual.Listar();
            return View(lista);
        }



    }
}
